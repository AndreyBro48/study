package com.todolist.main;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.todolist.db.TaskTableHelper;
import com.todolist.models.Task;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TaskTableHelper taskTableHelper;
    private ListView taskList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskTableHelper = new TaskTableHelper(this.getApplicationContext());
        taskList = (ListView)findViewById(R.id.tasksList);
    }

    @Override
    protected void onResume() {
        super.onResume();
        List<Task> tasks = taskTableHelper.findAll();
        ArrayAdapter<String> adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_multiple_choice, tasks);
        taskList.setAdapter(adapter);
    }
}
